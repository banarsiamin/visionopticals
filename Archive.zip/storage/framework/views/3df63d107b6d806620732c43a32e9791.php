<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vision Opticals - <?php echo $__env->yieldContent('title', 'Prescription'); ?></title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?php echo e(asset('img/favicon.png')); ?>">
    
    <!-- Mobiscroll CSS -->
    <link rel="stylesheet" href="https://cdn.mobiscroll.com/4.10.9/css/mobiscroll.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/prescription.css')); ?>">
    
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- Mobiscroll JS -->
    <script src="https://cdn.mobiscroll.com/4.10.9/js/mobiscroll.min.js"></script>
    
    <!-- Custom JS -->
    <script src="<?php echo e(asset('js/prescription.js')); ?>"></script>
    
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/vision-main/resources/views/vision/layouts/app.blade.php ENDPATH**/ ?>